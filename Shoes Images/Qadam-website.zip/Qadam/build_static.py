"""Generates static/js/data.js from data/*.json so the site also works without the backend."""
import json, pathlib
r = pathlib.Path(__file__).parent
p = json.loads((r/"data/products.json").read_text(encoding="utf-8"))
f = json.loads((r/"data/finance.json").read_text(encoding="utf-8"))
(r/"static/js/data.js").write_text("window.QADAM_DATA = " + json.dumps({"products": p, "finance": f}, ensure_ascii=False, indent=1) + ";\n", encoding="utf-8")
print("data.js written")
