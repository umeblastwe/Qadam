"""Qadam - Flask backend.

Run:  pip install -r requirements.txt
      python app.py          ->  http://127.0.0.1:5000
"""
import json, os, re, sqlite3
from datetime import datetime
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory, g

ROOT = Path(__file__).parent
DB_PATH = ROOT / "data" / "qadam.db"
ADMIN_KEY = os.environ.get("QADAM_ADMIN_KEY", "qadam123")   # change this before going live
FREE_DELIVERY_OVER = 5000
DELIVERY_FEE = 250

app = Flask(__name__, static_folder="static", static_url_path="/static")

PRODUCTS = json.loads((ROOT / "data/products.json").read_text(encoding="utf-8"))
FINANCE = json.loads((ROOT / "data/finance.json").read_text(encoding="utf-8"))
BY_ID = {p["id"]: p for p in PRODUCTS}


# ---------- database ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_):
    conn = g.pop("db", None)
    if conn:
        conn.close()


def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    with sqlite3.connect(DB_PATH) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS orders(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT, name TEXT, phone TEXT, city TEXT, address TEXT,
            product_id INTEGER, product_name TEXT, size TEXT, quantity INTEGER,
            subtotal INTEGER, delivery INTEGER, total INTEGER, note TEXT,
            status TEXT DEFAULT 'New')""")


# ---------- pages ----------
@app.get("/")
def home():
    return send_from_directory(ROOT, "index.html")


@app.get("/admin")
def admin_page():
    return send_from_directory(ROOT, "admin.html")


# ---------- API ----------
@app.get("/api/products")
def products():
    gender = request.args.get("gender")
    items = [p for p in PRODUCTS if not gender or p["gender"].lower() == gender.lower()]
    return jsonify(items)


@app.get("/api/finance")
def finance():
    return jsonify(FINANCE)


def calculate(units_by_id, cost_percent, expenses=None):
    """Monthly sales, expenses and profit. Same formula as the website calculator."""
    revenue = units = 0
    for pid, u in units_by_id.items():
        p = BY_ID.get(int(pid))
        if p:
            u = max(0, int(u))
            revenue += p["price"] * u
            units += u
    cogs = round(revenue * cost_percent / 100)
    opex = 0
    for e in FINANCE["monthlyExpenses"]:
        amt = (expenses or {}).get(e["key"], e["amount"])
        opex += amt * units if e["type"] == "perOrder" else amt
    profit = revenue - cogs - opex
    startup = sum(c["amount"] for c in FINANCE["startupCosts"])
    return {
        "units": units, "revenue": revenue, "cogs": cogs, "grossProfit": revenue - cogs,
        "expenses": opex, "netProfit": profit,
        "margin": round(profit / revenue * 100, 1) if revenue else 0,
        "startupCost": startup,
        "paybackMonths": round(startup / profit, 1) if profit > 0 else None,
    }


@app.post("/api/calculate")
def api_calculate():
    d = request.get_json(silent=True) or {}
    return jsonify(calculate(d.get("units", {}), float(d.get("costPercent", FINANCE["costPercent"])), d.get("expenses")))


@app.post("/api/orders")
def create_order():
    d = request.get_json(silent=True) or {}
    name = str(d.get("name", "")).strip()
    phone = re.sub(r"[\s\-]", "", str(d.get("phone", "")))
    city = str(d.get("city", "")).strip()
    address = str(d.get("address", "")).strip()
    size = str(d.get("size", "")).strip()
    note = str(d.get("note", "")).strip()[:300]
    try:
        qty = int(d.get("quantity", 1))
        product = BY_ID[int(d.get("productId"))]
    except (ValueError, TypeError, KeyError):
        return jsonify(error="Please choose a product."), 400

    errors = {}
    if len(name) < 2: errors["name"] = "Enter your full name."
    if not re.fullmatch(r"(\+92|0092|0)?3\d{9}", phone): errors["phone"] = "Enter a valid Pakistani mobile number, e.g. 0300 1234567."
    if len(city) < 2: errors["city"] = "Enter your city."
    if len(address) < 8: errors["address"] = "Enter your full delivery address."
    if not size: errors["size"] = "Choose a size."
    if not 1 <= qty <= 10: errors["quantity"] = "Quantity must be between 1 and 10."
    if errors:
        return jsonify(error="Please fix the highlighted fields.", fields=errors), 400

    subtotal = product["price"] * qty
    delivery = 0 if subtotal >= FREE_DELIVERY_OVER else DELIVERY_FEE
    cur = db().execute(
        "INSERT INTO orders(created_at,name,phone,city,address,product_id,product_name,size,quantity,subtotal,delivery,total,note)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (datetime.now().isoformat(timespec="seconds"), name, phone, city, address, product["id"],
         product["name"], size, qty, subtotal, delivery, subtotal + delivery, note))
    db().commit()
    return jsonify(ok=True, orderId=cur.lastrowid, subtotal=subtotal, delivery=delivery, total=subtotal + delivery), 201


def require_admin():
    key = request.headers.get("X-Admin-Key") or request.args.get("key")
    return key == ADMIN_KEY


@app.get("/api/orders")
def list_orders():
    if not require_admin():
        return jsonify(error="Wrong admin key."), 401
    rows = db().execute("SELECT * FROM orders ORDER BY id DESC").fetchall()
    return jsonify([dict(r) for r in rows])


@app.patch("/api/orders/<int:oid>")
def update_order(oid):
    if not require_admin():
        return jsonify(error="Wrong admin key."), 401
    status = (request.get_json(silent=True) or {}).get("status")
    if status not in ("New", "Confirmed", "Shipped", "Delivered", "Cancelled"):
        return jsonify(error="Invalid status."), 400
    db().execute("UPDATE orders SET status=? WHERE id=?", (status, oid))
    db().commit()
    return jsonify(ok=True)


init_db()

if __name__ == "__main__":
    app.run(debug=True, port=int(os.environ.get("PORT", 5000)))
